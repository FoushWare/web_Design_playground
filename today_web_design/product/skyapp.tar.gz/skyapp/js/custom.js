$(function(){ $('#home-heading').fitText(5, { minFontSize: '20px', maxFontSize: '30px' }); $('.section-primary-a h2').fitText(3, { minFontSize: '20px', maxFontSize: '30px' }); });
